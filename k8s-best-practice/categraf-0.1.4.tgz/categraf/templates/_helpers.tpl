{{- define "categraf.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "categraf.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{ include "categraf.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "categraf.selectorLabels" -}}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "categraf.namespace" -}}
{{ .Values.namespace | default "flashcat" }}
{{- end }}

{{- define "categraf.serverAddr" -}}
{{ .Values.categraf.serverAddr }}
{{- end }}

{{- define "categraf.heartbeatURL" -}}
{{ .Values.categraf.serverAddr }}/v1/n9e-plus/heartbeat?gid={{ .Values.categraf.heartbeatGid }}
{{- end }}

{{- define "categraf.remoteWriteURL" -}}
{{ .Values.categraf.serverAddr }}/prometheus/v1/write
{{- end }}
